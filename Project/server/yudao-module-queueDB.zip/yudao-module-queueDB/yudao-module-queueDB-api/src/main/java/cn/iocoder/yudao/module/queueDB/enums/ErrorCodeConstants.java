package cn.iocoder.yudao.module.queueDB.enums;

import cn.iocoder.yudao.framework.common.exception.ErrorCode;

public interface ErrorCodeConstants {
    ErrorCode FIELD_CONFIG_NOT_EXISTS = new ErrorCode(1_001_203_000, "动态字段配置不存在");
}